# Native save / gameplay activation observation — v0.36

This standalone DMM observation ASI records a later native loading boundary,
death/retry paths and explicit autosave loading. The completed manual-slot and
Continue/title sequences do not need repeating.

## Install

Close the game, replace the Save Detection observation entry in DMM with
`PywelAtlas-Save-Detection-Observation-v0.36.zip`, and keep other Atlas proof
ASIs disabled. The binary remains `PywelAtlasSaveDetectionProbe.asi`.
Launch the game and enter gameplay normally to begin the new sequence below.
Close the game before replacing/disabling this ASI; live unloading is unsupported.

## Next observation: four F7 checkpoints

1. Once you can move in gameplay, press **F7** and dismiss **OK**. This is the
   baseline for this run; there is no title-screen checkpoint.
2. On the **death/retry screen, before choosing retry**, press **F7** and dismiss
   **OK**. If this screen does not accept F7, report that and continue.
3. Choose the normal **retry/revive** option. Once you can move again, press
   **F7** and dismiss **OK**.
4. Open the game's Load menu, choose one explicitly labelled **autosave** and
   actually load it. Note its displayed label/time. Once you can move again,
   press **F7** and dismiss **OK**.

Tell Codex when finished, the autosave label/time, the retry option's wording,
and whether any checkpoint could not be recorded. Do not expect particular
counter/phase values: this run establishes them. No new manual save is needed.

The log remains `%LOCALAPPDATA%\PywelAtlas\native-save-detection.log`.
Sessions append with version/PID headers. F7 uses the already-confirmed
foreground/topmost popup on a separate thread; logging continues while it is
open. A duplicate press still records but does not open a second popup.

## What changed

v0.35 established successful read/apply/load chains and matching title cleanup.
It did not establish when gameplay became active. Static inspection now shows:

- The observed object is `ServerChildOnlyInGameActor`. Its `+5e` value `0x10`
  is reached inside apply and is too early to declare player control.
- The native `IsEnterToFieldLoadingComplete` condition follows the selected
  child and inspects its `+c3` byte. This is separate from `+5e`.
- A client loading controller clears that byte in phase 2, then has many later
  phases. Phase 23 waits for `+c3` to become nonzero before advancing to 24.
  Thus the early clear is not treated as the activation boundary.

v0.36 logs controller phase/object/byte changes, the early client reset, and
three field transition/reload paths alongside the existing five hooks. The
per-frame hook forwards the native floating-point elapsed-time argument;
unchanged snapshots are omitted to keep the queue bounded. Sequence numbers
can therefore have gaps even with zero dropped records.

`clientBoundary=1` only means a phase-24 snapshot matched the most recent
successful read/apply/load object's address, selected-child pointer and `+c3=1`,
with unchanged drop count. It remains diagnostic. It does not prove that a
death screen invalidated state, that retry read a disk slot, or that player
control was available at the precise native transition. Inspect the complete
trace and checkpoint chronology. An in-memory retry must not be described as
an autosave read without native read evidence.

## Boundaries and build

The probe installs ten entry-guarded observation detours, forwards consumed
register/stack arguments and native results, and preserves LastError. Callback
snapshots use bounded reads; worker/dialog threads never dereference stored
game pointers. Actor `+c3/+a0` and manager `+d0` reads require the exact supported
vtable layouts. Cleanup never rereads an object after native cleanup returns.

This ASI does not parse saves, switch accounts/slots, create/remove markers or
write game save files. The captured Steam root remains diagnostic. The Bell
reader is intentionally not wired until activation and alternative-load
evidence is established. Both trusted-state flags remain false.

Compiled with MSVC `/W4` without warnings. No automated tests added or run.
Runtime observation is pending. Source: `outputs/tools/native-map/` in the
continuation workspace; run `build.ps1 -Mode SaveLoad`. MinHook's BSD license
is included. No external companion process or installed Python is required.
