# Native save lifecycle observation — v0.35

The Manual save 2 -> Manual save 1 -> Manual save 2 sequence is already recorded
and does not need repeating. This version investigates Continue and leaving
for the title screen. No game save, marker or progress changes are made by the
probe, and no external companion is needed.

## Next sequence: Continue and title transitions

1. Close the game. In DMM replace the observation entry with this ZIP. Keep
   other Atlas proof ASIs disabled. The filename remains the distinct
   PywelAtlasSaveDetectionProbe.asi.
2. Launch and remain on the **title screen**. Press **F7**, then dismiss OK.
3. Choose **Continue**. Once you can move, press **F7** and dismiss OK.
4. Return to the **title screen** through the game's menu. Press **F7** and
   dismiss OK.
5. Choose **Continue** again. Once you can move, press **F7** and dismiss OK.
6. Tell Codex the sequence is done and whether each confirmation appeared in
   front. Codex will inspect all four logged checkpoints and lifecycle events.

No new manual save, deliberate death or repeat of the old two-slot sequence is
required. Normal game operations can autosave as usual. The probe itself never
opens or writes game save files. Close the game before replacing/disabling the
ASI; live unload is unsupported.

## F7 confirmation

F7 records before requesting a foreground/topmost confirmation on a separate
notification thread. Logging continues even if the popup is hidden or left open.
One popup at a time prevents duplicates; further F7 presses still record.
Dismiss with OK before continuing. The dialog includes:

- last requested slot and read/apply/outer-load return counts;
- whether one outer call has correlated successful read and apply on the same
  save object and slot;
- observed context cleanup count;
- whether the Steam handler's save-storage root was copied.

The correlation is a **candidate**, not a trusted loaded-save declaration. The
native return may precede player control. Initial title and post-title results
are observations to inspect, not hardcoded expected successes.

## Added lifecycle evidence

An outer wrapper encloses the native slot read and later apply. Its requested
slot is captured in a thread-local scope, restored after nested calls. Only
matching object/slot/read/apply/outer success in that scope can produce a
correlated candidate. Missing/dropped events, read/apply failure, unsupported
slot or a missing scope withhold correlation. No newest-file guess is involved.

A context cleanup hook records before/after events without dereferencing the
object after cleanup. If it matches the last load object, the worker clears
that diagnostic candidate. This may not cover every title/death path yet.

A Steam storage initialization hook copies its bounded root string while the
handler is live, after checking the Steam handler vtable. It is a diagnostic
path only, not an account selector. Only future observed paths can establish
whether this resolves the account directory. No account is guessed.

The old +0x60 field was not a slot and is no longer sampled. Raw +0x5e lifecycle
bits and vtable RVAs are now logged to guide further static analysis; they are
not interpreted as world readiness or used to change state.

## Implementation and files

Five entry-guarded detours forward original arguments/results and preserve
LastError: native read, apply, outer wrapper, context cleanup and Steam storage
initialization. All observations copy bounded values; the worker never
references live game objects. A bounded nonblocking queue reports drops, and
worker-owned scope records are capped at 16. Only the original game functions
run; the probe never independently requests a load.

Log: %LOCALAPPDATA%\PywelAtlas\native-save-detection.log. Sessions append with
version/PID/tick headers. User settings, earlier logs, snapshots and progress
remain intact. No save parser, automatic progress switching or marker hooks
are installed in this observation build. All trusted-state flags remain false.

The executable timestamp/image size and all five 24-byte entry guards must
match. The module is pinned for process lifetime. Build with
tools/native-map/build.ps1 -Mode SaveLoad. Compiled without warnings; no
automated tests added or run. Runtime observation is pending. MinHook BSD
license is included; no installed Python dependency exists.

After inspecting this sequence, address any missing Continue/title path and
activation/account evidence. Then cover death/autosave reloads before connecting
the loaded identity to progress. Do not claim those paths from manual loads.
