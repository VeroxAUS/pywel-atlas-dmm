# Native selected-save refresh proof — v0.32

v0.31 is user-confirmed: F7 removed the proof chest for completed Hernand Bell,
and a later F6 kept it hidden. Native save reading and visibility now work.
This build adds selection of existing save slots and periodic read-only refresh.

## Next check

1. Close the game, replace the previous ASI through DMM using this ZIP, and
   launch/load your save. Enable only this version.
2. Press **F9**. The native diagnostic selector shows an existing save and its
   local last-modified timestamp. **No** shows the next save; **Yes** selects it;
   **Cancel** keeps your selection. Choose **Manual save 2 (slot101)** initially.
3. Press **F7**. Confirm the selected slot is 101 and Hernand Bell is Save
   confirmed. Dismiss the dialog, open Pywel and press **F6**: no chest should appear.
4. Reopen F9 to check that Manual save 2 is still selected. Cancel to retain it.
5. Report whether selection and the F7/F6 result work. No new save is required.

No external program is required. Close the game before replacing/disabling the
ASI; never unload it live. F9 is a simple OS diagnostic selector inside the game
process; final styled in-game settings are pending.

## Selection and refresh rules

- The selector offers existing slotNNN/save.save files only, with modification
  timestamps. Known slot100/101 labels are Manual save 1/2; other slots retain
  their raw identifier so the prototype does not guess their meaning.
- Selection persists under mod AppData in native-save-selection.ini. Default is
  slot101. It is explicit selection, **not detection of the loaded game slot**.
  Select the same slot you loaded; loading a different game save requires F9.
- A changed selection disables the previous session link and requests cleanup
  of the old owned proof marker. Press F7 to enable the newly selected slot.
  No completion cache from the previous selection is applied to the new one.
- Successful F7 enables a session-only link: proof chest -> Hernand Bell. Every
  five seconds thereafter the mod reads a new stable snapshot of that slot.
  Explicit completion requests scoped removal when it changes to completed.
- Linked F6 always reads fresh bytes before allowing creation. Read failure
  withholds new creation and makes no completion decision. Periodic failures
  log the error without using stale reports or inferring completion.
- F10 remains manual cleanup. Refresh never automatically creates a marker;
  F6 is still required to display an unconfirmed proof location. The three-minute
  proof lifetime and focus-loss cleanup remain. Restart requires F7 again.

No personal pin, built-in Bell icon, manual progress or local marker JSON is
changed. The synthetic chest is still only a visibility proof, not a collectible.
Unconfirmed means no explicit completion evidence, not definitely undiscovered.
The selector does not validate the selected slot by comparing it to live game
state. Periodic refresh itself still awaits a changed-save runtime observation.

## Reader and files

All runtime save parsing is C++ in the mod. Game saves are opened read-only;
only two matching full byte/timestamp snapshots are decoded. Windows BCrypt
provides HMAC-SHA256; the reader handles the supported SAVE v2/ChaCha20/LZ4 and
bounded reflection metadata 3–4, serialization 11–15. Completion requires a
verified Bell UUID/type key and explicit _isCompleted=true. Eight Bell links
are embedded; only the single proof chest currently consumes Hernand completion.
Multiple numeric Steam account directories are rejected rather than guessed.

Local files under %LOCALAPPDATA%\PywelAtlas:

- native-save-selection.ini: selected slot (preserve as user settings).
- native-map-categories.log: v0.32 diagnostics.
- native-save-progress.json: latest successful selected-slot report, including
  profile, selectedSlot, timestamps and loadedSaveDetected=false.
- native-save-proof-ACCOUNT-slotNNN.save: stable encrypted diagnostic snapshot.

Old reports may remain after failures, but visibility never consumes them.
Snapshots and user settings are preserved. No save folder writes occur.

Build Categories compiled without warnings; no automated tests added or run.
F9 selection and periodic refresh await user confirmation. After this step,
expand from the synthetic chest to real Bell locations, then verified permanent
collectible categories. Native minimap expansion remains a separate task.
MinHook BSD and LukeFZ/pycrimson MIT licenses are included. Build-time Python
is not an installed dependency. The prior confirmed ZIP is archived under work.
