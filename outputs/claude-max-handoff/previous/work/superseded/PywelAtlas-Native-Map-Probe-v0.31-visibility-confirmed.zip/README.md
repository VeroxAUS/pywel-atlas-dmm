# Native save-linked marker proof — v0.31

Version 0.30 is user-confirmed: the native reader reported one recorded and
completed Bell, identifying Hernand Bell as Save confirmed in Manual save 2.
This build connects that result to the existing mod-owned proof chest.

## Next check

1. Close the game and replace the previous ASI through DMM using this ZIP.
   Enable only v0.31, then launch and load Manual save 2.
2. Open Pywel and press F6. Confirm the proof chest appears at its configured
   position east of the Bell (zoom if necessary, as in earlier proofs).
3. Press F7. The dialog should report Hernand Bell as Save confirmed and say
   that chest removal was requested. Dismiss it and open/keep Pywel visible.
4. Confirm the proof chest disappears. Press F6 again: it should remain absent.
   Your original personal pins and the game's Bell icon should remain unchanged.
5. Report the removal and whether F6 kept the chest hidden.

No helper application or new game save is required. Close the game before
replacing/disabling the ASI; never unload it live.

## Explicit session link

F6 initially uses the existing unlinked JSON proof, preserving its coordinates
and completion.source=none. A successful F7 enables an experimental session-only
link from this synthetic chest to Hernand Bell (mg:543894), explicitly in Manual
save 2 (slot101). This is a visibility proof, not a claim the chest represents a
real collectible. The local JSON and user progress are not modified.

Once linked, every F6 takes a new stable save snapshot. Explicit completion
blocks creation and requests removal using the existing private-key ownership
and identity checks on the game's map thread. Unconfirmed completion permits
creation; it does not assert that a location is definitely undiscovered.
F7 can refresh the link and remove an existing proof chest. Unconfirmed F7
results do not create a marker automatically. F10 remains manual cleanup.

A failed read does not infer completion, request completion removal, or use an
old report as current evidence. F6 with a failed read withholds new creation
and retains existing state. There is no continuous watcher or loaded-slot
detection. The link resets on restart; F7 must explicitly enable it again.
Changing to a different loaded save does not change the diagnostic slot.

## Native reader and data protection

All runtime parsing is C++ inside the mod, with no Python/helper process.
Game saves are opened read-only. Two matching full byte/timestamp reads provide
stable snapshot bytes; only that copy is decoded. Local encrypted snapshots,
reports and logs stay under %LOCALAPPDATA%\PywelAtlas and must be preserved.

The reader supports SAVE envelope version 2, ChaCha20, HMAC-SHA256 via Windows
BCrypt, bounded LZ4, reflection metadata 3–4 and serialization 11–15. Only the
unique supported Bell discovery list is used. Completion requires a verified
UUID, allowed type key and explicit _isCompleted=true. No proximity inference.
Eight Bell identity links are embedded from data/bell-save-links.json.
Multiple numeric Steam account directories are rejected rather than guessed.

- Log: native-map-categories.log (startup v0.31).
- Report: native-save-progress.json, with selected profile/slot and timestamps.
- Snapshot: native-save-proof-ACCOUNT-slot101.save.

Failed reads retain the prior diagnostic report, which is not fresh evidence.
The report is not an input to marker visibility. No saved pin serializer,
manual progress change or game save write is involved.

## Status and direction

The intended product is one DMM-installed mod handling data and display.
The fallback is one overlay application handling both tasks. The original
companion remains available as research/fallback; it is not a dependency.

Build Categories compiled without warnings. No automated tests added or run.
Native save reading is confirmed; v0.31 visibility linkage awaits user results.
After this proof, add explicit slot selection and refresh/state handling, then
expand marker collections using verified completion records.

MinHook BSD and LukeFZ/pycrimson MIT licenses are included. Format interpretation
is adapted from pycrimson; the LZ4 decoder follows its published block format.
Build-time Python generators are developer tools, not installed dependencies.
