# Standalone native save proof — v0.30

The existing marker path is working. Version 0.29 confirmed that changing local
JSON X moved the native chest correctly. Version 0.30 adds a separate native
save-reading proof; it does not require the companion application or Python.

## One new check

1. Close Crimson Desert and replace the previous ASI in DMM using this ZIP.
   Enable only v0.30, then launch the game normally.
2. With your save loaded, press **F7** once.
3. A diagnostic dialog should report **Manual save 2** and **Hernand Bell:
   Save confirmed**. Report that result or the exact error shown.

No other application needs to be opened or closed. No F6/F10 marker cycle,
coordinate edit, new pin or game save is needed for this check. The diagnostic
explicitly reads Manual save 2; it does not detect which slot is currently loaded.
The existing F6/F10 marker features remain available. The F7 result does not
change markers yet; the next step is connecting verified completion to visibility.
Close the game before replacing/disabling an ASI; never unload it live.

## What runs inside the mod

F7 runs a C++ reader on the plugin's worker thread. It opens the game save with
read-only access, takes two matching timestamp/byte reads, and decodes only that
stable snapshot. The game's save directory is never opened for write. A local
encrypted snapshot is retained under the mod's AppData for diagnostics.

The reader supports save envelope version 2, derives its native key, decrypts
ChaCha20, verifies HMAC-SHA256 using Windows BCrypt, then expands bounded LZ4
blocks. Save/reflection format interpretation is adapted from LukeFZ/pycrimson;
its MIT license is included. No Python interpreter or external process runs.
The LZ4 decoder follows the published block format and bounds every read/write.

Only reflection metadata versions 3–4 and serialization versions 11–15 are
accepted by this first implementation. The type/object tables are checked;
only the unique supported Bell discovery container/list is parsed for progress.
Nesting, object counts, strings, payload sizes, offsets and property kinds are
bounded. Unknown/unsupported structures fail without confirming completion.

A Bell is confirmed only by its verified UUID, allowed native type key and an
explicit boolean _isCompleted=true in that container's records. Eight verified
Bell links are embedded from outputs/data/bell-save-links.json. Unrecorded or
recorded-without-completion stays unconfirmed. No proximity inference is used.

Diagnostic selection is Manual save 2 (slot101), in the sole numeric Steam
account directory. Multiple accounts are rejected rather than guessed. General
slot selection and loaded-slot detection are not implemented. F7 uses an OS
diagnostic dialog owned by the game process; final in-game settings UI is pending.

## Results and limits

- Log: %LOCALAPPDATA%\PywelAtlas\native-map-categories.log (startup v0.30).
- Report: %LOCALAPPDATA%\PywelAtlas\native-save-progress.json.
- Stable encrypted snapshot: native-save-proof-ACCOUNT-slot101.save in that folder.

The report includes selected profile, timestamps, loadedSaveDetected=false and
per-Bell states. A failed read produces a dialog/log error and does not replace
a previous successful report. Old reports are not evidence of the failed read.
No completion-driven marker removal, automatic slot detection or continuous
watching is enabled yet. These diagnostics are application data and must be
preserved during cleanup.

The working marker lifecycle and local JSON definition remain intact. The
single proof location still is not a real collectible. Save reading is isolated
from the native map callbacks; only copied values will cross to UI when wired.
If this read succeeds, next bind one verified completion result to a mod-owned
marker, then extend supported categories after explicit record mapping.

## Product direction

The intended release is one DMM-installed in-game mod handling data and marker
display. If dependable native integration proves unworkable, the fallback is one
overlay application handling both tasks. A companion-plus-mod dependency is not
the chosen product. Existing desktop files are retained as fallback/research.

Build Categories compiled without warnings. No automated tests added or run;
user confirmation of native save parsing is pending. Build-time generators use
developer Python only; the installed ASI does not. MinHook BSD and pycrimson MIT
licenses are included.
